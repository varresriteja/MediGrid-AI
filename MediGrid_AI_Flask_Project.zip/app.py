from flask import Flask, render_template, jsonify, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, timedelta
import random, math, os

app=Flask(__name__); app.config['SECRET_KEY']='medigrid-demo'; app.config['SQLALCHEMY_DATABASE_URI']='sqlite:///medigrid.db'; app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False
db=SQLAlchemy(app)
class Facility(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120)); city=db.Column(db.String(80)); lat=db.Column(db.Float); lon=db.Column(db.Float)
class Medicine(db.Model):
 id=db.Column(db.Integer,primary_key=True); name=db.Column(db.String(120)); category=db.Column(db.String(80)); criticality=db.Column(db.Integer,default=3)
class Inventory(db.Model):
 id=db.Column(db.Integer,primary_key=True); facility_id=db.Column(db.Integer); medicine_id=db.Column(db.Integer); quantity=db.Column(db.Integer); reserved=db.Column(db.Integer,default=0); expiry=db.Column(db.Date); daily_demand=db.Column(db.Float)
class Transfer(db.Model):
 id=db.Column(db.Integer,primary_key=True); source_id=db.Column(db.Integer); dest_id=db.Column(db.Integer); medicine_id=db.Column(db.Integer); quantity=db.Column(db.Integer); status=db.Column(db.String(30)); created=db.Column(db.DateTime,default=datetime.utcnow)
class Activity(db.Model):
 id=db.Column(db.Integer,primary_key=True); message=db.Column(db.String(255)); created=db.Column(db.DateTime,default=datetime.utcnow)
def seed():
 if Facility.query.count(): return
 cities=[('Hyderabad Central','Hyderabad',17.385,78.486),('Secunderabad Care','Secunderabad',17.44,78.50),('Warangal District','Warangal',17.97,79.59),('Nizamabad General','Nizamabad',18.67,78.09),('Karimnagar Health','Karimnagar',18.44,79.12),('Khammam Medical','Khammam',17.25,80.15),('Nalgonda Community','Nalgonda',17.05,79.27),('Adilabad Rural','Adilabad',19.66,78.53)]
 for x in cities: db.session.add(Facility(name=x[0],city=x[1],lat=x[2],lon=x[3]))
 meds=[('Paracetamol','Analgesic',4),('Insulin','Diabetes',5),('Amoxicillin','Antibiotic',4),('ORS Sachets','Rehydration',3),('Salbutamol','Respiratory',4),('Ceftriaxone','Antibiotic',5),('Metformin','Diabetes',3),('Azithromycin','Antibiotic',4),('IV Fluids','Emergency',5),('Antiseptic','General',2),('Aspirin','Cardiac',4),('Atorvastatin','Cardiac',3)]
 for x in meds: db.session.add(Medicine(name=x[0],category=x[1],criticality=x[2]))
 db.session.commit()
 for f in Facility.query.all():
  for m in Medicine.query.all():
   demand=random.uniform(4,18); qty=random.randint(20,300)
   if f.id==1 and m.id in [2,6,9]: qty=random.randint(3,18)
   exp=datetime.utcnow().date()+timedelta(days=random.choice([25,45,90,180,300]))
   db.session.add(Inventory(facility_id=f.id,medicine_id=m.id,quantity=qty,reserved=random.randint(0,5),expiry=exp,daily_demand=round(demand,1)))
 db.session.add(Activity(message='MediGrid network initialized with synthetic healthcare data'))
 db.session.commit()
def metrics():
 inv=Inventory.query.all(); today=datetime.utcnow().date()
 rows=[]
 for i in inv:
  avail=max(0,i.quantity-i.reserved); days=avail/max(i.daily_demand,0.1); expiry=(i.expiry-today).days
  stockrisk=max(0,min(100,(30-days)*3.2)); exprisk=max(0,min(100,(60-expiry)*1.5))
  score=min(100,round(stockrisk*.45+exprisk*.15+Medicine.query.get(i.medicine_id).criticality*8+ (20 if i.daily_demand>12 else 0)))
  level='Critical' if score>=75 else 'High' if score>=50 else 'Moderate' if score>=25 else 'Low'
  rows.append(dict(id=i.id,facility=Facility.query.get(i.facility_id).name,medicine=Medicine.query.get(i.medicine_id).name,available=avail,demand=i.daily_demand,days=round(days,1),expiry=expiry,score=score,level=level))
 return rows
@app.route('/')
def dashboard():
 r=metrics(); return render_template('dashboard.html', rows=r, facilities=Facility.query.count(), medicines=Medicine.query.count(), critical=sum(x['level']=='Critical' for x in r), high=sum(x['level']=='High' for x in r), transfers=Transfer.query.count())
@app.route('/inventory')
def inventory(): return render_template('inventory.html', rows=metrics())
@app.route('/predictions')
def predictions(): return render_template('predictions.html', rows=sorted(metrics(),key=lambda x:x['days']))
@app.route('/risk')
def risk(): return render_template('risk.html', rows=sorted(metrics(),key=lambda x:-x['score']))
@app.route('/redistribution')
def redistribution():
 r=metrics(); rec=[]
 for x in r:
  if x['days']<4:
   sources=[s for s in r if s['medicine']==x['medicine'] and s['days']>12 and s['facility']!=x['facility']]
   if sources:
    s=max(sources,key=lambda z:z['available']); rec.append((x,s,min(s['available']//2,max(1,int(x['demand']*4-x['available'])))))
 return render_template('redistribution.html', rec=rec)
@app.route('/transfer',methods=['POST'])
def transfer():
 dest,src,med,qty=request.form['dest'],request.form['src'],request.form['med'],int(request.form['qty'])
 di=next(x for x in metrics() if x['facility']==dest and x['medicine']==med); si=next(x for x in metrics() if x['facility']==src and x['medicine']==med)
 a=Inventory.query.get(di['id']); b=Inventory.query.get(si['id']); q=min(qty,b.quantity-b.reserved)
 if q>0: b.quantity-=q; a.quantity+=q; db.session.add(Transfer(source_id=b.facility_id,dest_id=a.facility_id,medicine_id=a.medicine_id,quantity=q,status='Approved')); db.session.add(Activity(message=f'Approved transfer: {q} units of {med} from {src} to {dest}')); db.session.commit()
 return redirect(url_for('redistribution'))
@app.route('/emergency',methods=['GET','POST'])
def emergency():
 result=None
 if request.method=='POST':
  med=request.form['med']; qty=int(request.form['qty']); sources=[x for x in metrics() if x['medicine']==med and x['available']>=qty]
  result=min(sources,key=lambda x:x['days']) if sources else None
 return render_template('emergency.html',medicines=Medicine.query.all(),result=result)
@app.route('/simulation',methods=['GET','POST'])
def simulation():
 result=None
 if request.method=='POST':
  surge=float(request.form['surge']); r=metrics(); result=[(x,round(x['days']/(1+surge/100),1)) for x in r if x['days']<15]
 return render_template('simulation.html',result=result)
@app.route('/alerts')
def alerts(): return render_template('alerts.html', rows=[x for x in metrics() if x['score']>=50 or x['expiry']<45])
@app.route('/reports')
def reports(): return render_template('reports.html', rows=metrics())
with app.app_context(): db.create_all(); seed()
if __name__=='__main__': app.run(debug=True)
